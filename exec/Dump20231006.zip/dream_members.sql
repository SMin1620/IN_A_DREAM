CREATE DATABASE  IF NOT EXISTS `dream` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `dream`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 13.124.105.1    Database: dream
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `is_write` int NOT NULL,
  `negative_coin` int NOT NULL,
  `neutral_coin` int NOT NULL,
  `positive_coin` int NOT NULL,
  `create_at` datetime(6) NOT NULL,
  `member_id` bigint NOT NULL AUTO_INCREMENT,
  `birth` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refresh_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `UK_9d30a9u1qpg8eou0otgkwrp5d` (`email`),
  UNIQUE KEY `UK_e6u9u9ypoc7oldnpxdjwcdx3` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (8,344,1731,624,'2023-10-01 05:45:19.199835',1,'모름','email@naver.com','male','차두리','$2a$10$0Xf4Z2poTqbzzUb0Eol/5eIe.XhEQ/Hdl1fsI3ye4WLQTMrza2LEi',NULL),(5,323,337,540,'2023-10-01 05:45:47.507032',2,'1998-03-23','bajh323@naver.com','female','자롱이','$2a$10$nfoS1HVl.x2fBY4kOl1Qi.wJXlZvMXO1FVUOtuBXNrlMH/wW3oxda',NULL),(2,2184,3753,4905,'2023-10-01 05:45:56.196812',3,'2023-01-31','qwe123@naver.com','male','즐거운추석','$2a$10$MfHaHMVQ1Gc/rsie19TsoO1zD3nC2iN4zSHqJBhvObwdVezxo/rKi',NULL),(98,270,416,184,'2023-10-01 05:50:27.716940',4,'1997-10-14','krkdhs6240@naver.com','male','swan','$2a$10$nEBbzeVi9SqMS7CoxaXLWu3nURGusLyH44nP7UmwXPI7/xH9oykoy',NULL),(8,1100,1000,1000,'2023-10-01 07:23:51.486337',5,'1997-01-29','slave@slave.kr','male','slavekim','$2a$10$EaS8CnM/tEPXhuyaHOkSFej71YU/aWrdcFMWCA/sI.Lu6VuR9a0dS',NULL),(1,938,1693,1067,'2023-10-03 17:09:15.515705',6,'2002-02-14','whwhdnfl2@naver.com','male','차두리어카','$2a$10$HZxC4ryv2/bKU4cRU8hJLONLRJcC1COAgVWDy2p9ULccF9.tyav4K',NULL),(9,905,1085,885,'2023-10-04 00:15:57.895541',7,'2000-02-02','ssafy1@ssafy.com','male','컨설턴트님','$2a$10$RHB4EirP/G4q/DN2IqQWuuiwWxCVHcOyLDt/QV1x3WFQODktcPP3i',NULL),(6,1046,1009,1145,'2023-10-04 00:28:59.222116',8,'2002-02-05','ssafy2@ssafy.com','female','보경코치님','$2a$10$YmlWFJeB9gEjgqBcrZO/weYqoNWtFIVcxSEi.lMnyt0JSKOUBHtNW',NULL),(5,92,357,251,'2023-10-04 00:30:40.346371',9,'2000-08-24','ssafy3@ssafy.com','male','인모코치님','$2a$10$TqPuo5rs9VDyD3L1L2NwLOit.5ZH21b8.j6yF1wVlBPiBjumh6wqu',NULL),(10,0,0,0,'2023-10-04 00:53:04.580188',10,'1993-01-11','rngus3050@gmail.com','male','rngus3050','$2a$10$GCgNH3DYNODbulYPavyS0u8YGjOkEYZwNc/A0kXAH8H7Mbka7xruK',NULL),(1,1932,1448,1350,'2023-10-04 06:49:58.368145',11,'2020-07-04','gusejr4547@ssafy.com','male','나는현덕','$2a$10$53UVHTN9YXN0uLSuoKdUcuMIa1/M2oB61/cI7JpK9x7h8l8/9iadW',NULL),(10,503,187,210,'2023-10-04 07:07:26.706386',12,'2012-04-06','asd@naver.com','male','아이폰','$2a$10$g/iaB4sgQI.Lq8ixu50PQurxIyKr8WQKmn1t2H3Fexxn6TIaYUo9e',NULL),(9,100,0,0,'2023-10-04 11:56:51.732394',13,'1998-07-09','tlswldnjs951@naver.com','female','먼작귀','$2a$10$47zY5.Y9fjeCay0vq8sZmu8ks2QgV/nGnfpfcM7bZridHghr8COzW',NULL),(9,80,19,1,'2023-10-04 12:03:46.363889',14,'1997-04-27','index131@naver.com','male','국뽕선비','$2a$10$yc2HTGwDQPg.1JoPsBMIBuYtPwz/aeOetj3Za2cabG/h0PhiC33Dm',NULL),(10,0,0,0,'2023-10-04 12:10:28.633974',15,'1998-09-24','lsn6968@naver.com','female','이묘','$2a$10$EJuOI5TT7ZUMggYbJAlJ..mDPWHFdHUgxnGvBd7ycxyjlC5kjr/Le',NULL),(10,278,96,226,'2023-10-05 02:40:17.108416',16,'2023-10-19','siu@naver.com','female','축구국대','$2a$10$8CaOHX2BQXMaCXcjTvc67e445eH6uPawzwwZkEpJ0uCv/Eg3RZgle',NULL),(1,0,0,0,'2023-10-05 04:48:51.978836',17,'1987-02-26','light@ssafy.com','male','최번개','$2a$10$OjPsMPkuO5qmGbaphesHreK6rk7tub3mWk0nLTK628ynl3s5E67ga',NULL),(1,0,34,166,'2023-10-05 05:46:52.638515',19,'1998-03-05','poison@ssafy.com','male','독두꺼비','$2a$10$OoUVqrVQjHGwM0.RgK1tQ.C0zaUzOL5JzJEIm7HhpuvgeCwtpilLu',NULL),(1,0,0,0,'2023-10-05 06:19:12.503894',20,'2023-10-16','test','male','test','$2a$10$UIhgLQKJj3wRbH0m0BJWv.4Y/EYVUAcsxNHMq8Us877tLW249VQMq',NULL),(1,0,100,0,'2023-10-05 06:22:45.395164',21,'2023-10-01','crazygun22@nate.com','male','crazygun22','$2a$10$gU6tUqWuPbzW3EVutiqlMOSzrCBSIxvLPuVC9p2qpguv2yZJRxPsW',NULL),(1,0,0,200,'2023-10-05 06:45:19.472163',22,'2023-10-04','qwer@naver.com','male','똥을싸','$2a$10$dOavlrucy03zJpRdkRifMu6ENSWHBUqNQYCViXcbSsUoVwAW9KZqO',NULL),(1,0,0,200,'2023-10-05 07:17:58.233158',23,'2023-10-03','qweqwe@naver.com','male','호날듀','$2a$10$2e8nKAItYbEcbrXx0/KHc./bpEyrN9BFX6uAz0ZBW43wT8b4Jc6uu',NULL),(1,100,0,0,'2023-10-05 07:44:25.161914',24,'1997-03-19','gms04129@naver.com','male','로준','$2a$10$hB.QKPb8TEFQurnUGCP0TemaE10jObL7Y3xOr4hA43dXk7HSElFOi',NULL),(1,0,0,100,'2023-10-05 08:56:33.296091',25,'1997-10-14','wjdtndhks12@gmail.com','male','swannnn','$2a$10$8nSsweFUMJ77VRQ7/lgSJe/IYdQQAAePzRPydi/3pkHLEpMUdMvbC',NULL),(1,100,0,0,'2023-10-05 12:26:04.386334',26,'1997-09-08','sunwha@naver.com','male','선화식당','$2a$10$WXDL53X3uw80TGgQUKNB6ewGmrGfDUq.IV8q2SLayoGW18BWeWOXS',NULL);
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-06 10:19:09
